public class Variable06 {
	public static void main(String[] args) {
		//부울형(논리형) : boolean(1Byte)
		//true, false 만 기억 ▶ 조건식 작성
		boolean t = true;
		boolean f = false;
		
		System.out.println("변수 t의 값 : " + t);
		System.out.println("변수 f의 값 : " + f);
	}//main()
}//class