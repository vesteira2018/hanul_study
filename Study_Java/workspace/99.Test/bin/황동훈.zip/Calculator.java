public class Calculator {
	//덧셈
	public static int sum(int x, int y) {
		int sum = x + y;
		
		return sum;
	}
	
	//뺄셈
	public static int sub(int x, int y) {
		int sub = x - y;
				
		return sub;
	}
	
	//곱셈
	public static int mul(int x, int y) {
		int mul = x * y;
		
		return mul;
	}
	
	//나눗셈
	public static int div(int x, int y) {
		int div = x / y;
		
		return div;
	}
}
