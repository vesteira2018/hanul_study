public class Max {
	public static void main(String[] args) {
		int num1 = 152;
		int num2 = 173;
		int max;
		if (num1 > num2) {
			max = num1;
		} else {
			max = num2;
		}
		System.out.println(max);
	}
}
