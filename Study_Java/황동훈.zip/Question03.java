public class Question03 {
	//멤버변수
	int x, y;

	//덧셈
	public static int add(int x, int y) {
		int add = x + y;
		return add;
	}
	
	//뺄셈
	public static int sub(int x, int y) {
		int sub = x - y;
		return sub;
	}
	
	//곱셈
	public static int mul(int x, int y) {
		int mul = x * y;
		return mul;
	}
	
	//나눗셈
	public static int div(int x, int y) {
		int div = x / y;
		return div;
	}
	
}
