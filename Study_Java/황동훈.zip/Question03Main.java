public class Question03Main {
	public static void main(String[] args) {
		System.out.println("덧셈 : 5 + 3 = " + Question03.add(5, 3));
		System.out.println("뺄셈 : 9 - 7 = " + Question03.sub(9, 7));
		System.out.println("곱셈 : 8 * 4 = " + Question03.mul(8, 4));
		System.out.println("나눗셈 : 12 / 6 = " + Question03.div(12, 6));
	}//main()
}//class
